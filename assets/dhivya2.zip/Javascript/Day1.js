const name="Ranjini is my Name"
console.log(name)

let age=21
console.log(age)

let likecoding =true
console.log(likecoding)

let unlikecoding =false
console.log(unlikecoding)

let likelang=new Array('Java','C','Javascript')
console.log(likelang)

let num1=10;
let num2=20;

console.log(num1+num2)
console.log(num2-num1)
console.log(num1*num2)
console.log(num2/num1)
console.log(num1%num2)